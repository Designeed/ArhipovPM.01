﻿using PawnshopApp.model.dataSource;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PawnshopApp.model.dao
{
    class db
    {
        private static PawnshopDBEntities psEntity;

        public static PawnshopDBEntities GetContext()
        {
            if (psEntity == null) psEntity = new PawnshopDBEntities();
            return psEntity;
        }
    }
}
