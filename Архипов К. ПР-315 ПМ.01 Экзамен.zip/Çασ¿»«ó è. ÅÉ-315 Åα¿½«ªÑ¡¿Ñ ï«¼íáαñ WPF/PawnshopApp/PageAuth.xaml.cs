﻿using PawnshopApp.model.dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PawnshopApp
{
    /// <summary>
    /// Логика взаимодействия для PageAuth.xaml
    /// </summary>
    public partial class PageAuth : Page
    {
        public PageAuth()
        {
            InitializeComponent();
        }

        private void bLogin_Click(object sender, RoutedEventArgs e)
        {
            if (auth(pbPassword.Password, tbLogin.Text))
            {
                openWindow();
            }
        }

        public static bool auth(string password, string login)
        {
            try
            {
                if (login != "" && password != "")
                {
                    string loginCurUser = login;
                    string passwordCurUser = password;

                    var user = db.GetContext().employees.ToList().Find(l => l.login == loginCurUser);

                    if (user != null)
                    {
                        if (passwordCurUser == user.password)
                        {
                            return true;
                        }
                        else MessageBox.Show("Неверный пароль!");
                    }
                    else MessageBox.Show("Пользователь не найден!");
                }
                else MessageBox.Show("Заполните поля");

                return false;
            }
            catch
            {
                MessageBox.Show("Неверный пароль!");
                return false;
            }
        }

        private void openWindow()
        {
            this.NavigationService.Navigate(new PageHome(), UriKind.Relative);
        }

        private void clearField()
        {
            if (tbLogin.Text != "" && pbPassword.Password != "")
            {
                tbLogin.Text = "";
                pbPassword.Password = "";
            }
        }

        private void bCancel_Click(object sender, RoutedEventArgs e)
        {
            clearField();
        }
    }
}
