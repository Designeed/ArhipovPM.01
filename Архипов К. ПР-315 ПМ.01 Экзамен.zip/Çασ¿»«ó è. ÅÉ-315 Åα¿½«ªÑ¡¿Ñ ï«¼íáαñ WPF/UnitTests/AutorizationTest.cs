﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PawnshopApp;
using System;

namespace UnitTests
{
    [TestClass]
    public class AutorizationTest
    {
        [TestMethod]
        public void AuthTest()
        {
            string password = "den228";
            string login = "den";

            bool result = PageAuth.auth(password, login);

            Assert.AreEqual(result, false);
        }
    }
}
