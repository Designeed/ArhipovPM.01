package com.example.arkhipovtaxiappmobile

import android.util.Patterns

fun String.validateEmail() : Boolean{
    val regexEmail = "^[A-Za-z](.*)([@])(.+)(\\.)(.+)"
    return regexEmail.toRegex().matches(this)
}

fun String.passEqual(password: String) : Boolean{
    return this == password
}