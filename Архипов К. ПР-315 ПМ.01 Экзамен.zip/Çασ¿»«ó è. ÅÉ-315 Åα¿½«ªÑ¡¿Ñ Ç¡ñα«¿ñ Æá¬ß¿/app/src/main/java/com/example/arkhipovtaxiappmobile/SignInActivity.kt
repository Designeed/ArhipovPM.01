package com.example.arkhipovtaxiappmobile

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.arkhipovtaxiappmobile.databinding.ActivitySignInBinding

class SignInActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignInBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.bSignIn.setOnClickListener{
            //проверка на пустой логин
            if(binding.etMail.text.isEmpty()) {
                Toast.makeText(this, "Empty Login", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            //проверка на правильность почты
            if(!binding.etMail.text.toString().validateEmail()) {
                Toast.makeText(this, "Invalid E-Mail", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            //проверка на заполненность пароля
            if(binding.etPass.text.isEmpty()) {
                Toast.makeText(this, "Empty Password", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            startActivity(Intent(this, MainActivity::class.java))
        }

        binding.button3.setOnClickListener{
            startActivity(Intent(this, SignUpActivity::class.java))
        }
    }
}