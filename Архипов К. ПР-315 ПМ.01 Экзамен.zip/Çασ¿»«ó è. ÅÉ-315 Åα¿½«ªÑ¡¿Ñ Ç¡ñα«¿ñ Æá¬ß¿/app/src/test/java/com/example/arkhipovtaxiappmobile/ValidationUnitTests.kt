package com.example.arkhipovtaxiappmobile

import org.junit.Test

import org.junit.Assert.*

class ValidationUnitTests {
    //тест на правильность валидации почты
    @Test
    fun email_is_valid() {
        val email = "konst@mail.ru"
        assertEquals(email.validateEmail(), true)
    }

    //тест на правильность работы функции сравнения паролей
    @Test
    fun password_is_match(){
        val pass1 = "password"
        val pass2 = "password"
        assertEquals(pass1.passEqual(pass2), true)
    }
}